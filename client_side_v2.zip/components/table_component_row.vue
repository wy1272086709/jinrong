<template>
	<view>
		<table-col></table-col>
	</view>
</template>

<script>
	import tableCol from './table_component_col.vue';
	export default {
		// 一行对应的元素
		props:{
			
		},
		data() {
			return {
				
			};
		},
		components:{
			tableCol
		}
	}
</script>

<style>

</style>
